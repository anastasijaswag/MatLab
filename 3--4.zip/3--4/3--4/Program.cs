﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Let_DEmo
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] strs = { "ALPHA", "BETA",   "GAMMA", "DELTA", "OMEGAAA" };
            Console.WriteLine("Исходный массив :");
            foreach (string i in strs)
                Console.Write(i + " ");
            Console.WriteLine("\n");
            Console.ReadKey();


           
            var sort = from str in strs
                       orderby str.Length ascending
                       orderby str
                       select str;


            Console.WriteLine("  Строки отсортированные по возрастанию длины + строки одинаковой длины — по убыванию");
            foreach (var i  in sort)
                Console.Write(i + " ");
            Console.WriteLine();
            Console.ReadKey();




            IEnumerable<string> reverse_strs = strs.Reverse();

            var letter = from l in reverse_strs
                         let res = l.Substring(0,1)
                         from p in res
                         select p;


            Console.WriteLine(" Первые символы из строк отсортированные в обратном порядке");
            foreach (var i in letter)
                Console.Write(i + " ");
            Console.WriteLine();
            Console.ReadKey();



        }
    }
}