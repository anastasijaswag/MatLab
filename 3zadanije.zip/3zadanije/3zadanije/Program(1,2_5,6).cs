﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _3zadanije
{
    class Program
    {

        static void Main(string[] args)
        {
            int[] nums = { 10, -20, 4, 77, -5, 23, -6, 800, 0, 8 };

            Console.WriteLine("Исходный массив :");
            foreach (int i in nums)
                Console.Write(i + " ");
            Console.WriteLine("\n");
            Console.ReadKey();

            IEnumerable<int> distinct_num = nums.Distinct();

            var odd_num = from n in distinct_num
                          where n%2 == 0
                          select n;
            

            Console.WriteLine("(1) Массив c четными числами :");
            foreach(int i in odd_num)
                Console.Write(i + " ");
            Console.WriteLine("\n");




            var sort_num = from n in nums
                           orderby n
                           where n>9 && n<100
                           select n;


            Console.WriteLine("(2) Массив положительный осортированный двухзначный:");
            foreach (int i in sort_num)
                Console.Write(i + " ");
            Console.WriteLine("\n");


            var last_digit = from n in nums
                             where n > 0
                             select n % 10;

            IEnumerable<int> distinct_last_digit = last_digit.Distinct();

            Console.WriteLine("(5) Массив с последними цифрами :");
            foreach (int i in distinct_last_digit)
                Console.Write(i + " ");
            Console.WriteLine("\n");


            var sort_divide = from n in nums
                              where n % 3 != 0
                              select n;

            Console.WriteLine("(6) Массив с делмостью на 3 :");
         //?????   foreach (int i in nums.SkipWhile(i => Math.Abs(i) % 3 == 0))
            foreach (int i in sort_divide)
            {
                if (i%3 == 1)
                {
                    Console.Write(i*2 + " ");
                }
                else
                Console.Write(i + " ");
            }
            Console.WriteLine("\n");
            Console.ReadKey();




        }
     
    }

}
