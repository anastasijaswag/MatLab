﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Let_DEmo
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] strs = { "ALPHA", "BETA", "GAMMA", "DELTA", "OMEGAAA" };
            //Отсортировать последовательность по возрастанию длин строк, а строки одинаковой длины — по убыванию.
            var chrs = from str in strs
                       let chrArray = str.ToCharArray()
                       from ch in chrArray
                       orderby ch
                       select ch;
            Console.WriteLine(" Символы из строк отсортированные по порядку");

            foreach (char c in chrs)
                Console.Write(c + " ");
            Console.WriteLine();
            Console.ReadKey();
        }
    }
}
